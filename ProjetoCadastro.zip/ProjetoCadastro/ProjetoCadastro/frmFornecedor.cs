﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCadastro
{
    public partial class frmFornecedor : Form
    {
        private void HabilitaEdicao()
        {
            nm_fornecedor.Enabled = true;
            ds_endereco.Enabled = true;
            nm_bairro.Enabled = true;
            nm_cidade.Enabled = true;
            sg_estado.Enabled = true;
            cd_cep.Enabled = true;
            cd_cnpj.Enabled = true;
            cd_ie.Enabled = true;
            btnAnterior.Enabled = false;
            btnProximo.Enabled = false;
            btnNovo.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;
            btnPesquisar.Enabled = false;
            btnImprimir.Enabled = false;
            btnSair.Enabled = false;
        }

        private void DesabilitaEdicao()
        {
            nm_fornecedor.Enabled = false;
            ds_endereco.Enabled = false;
            nm_bairro.Enabled = false;
            nm_cidade.Enabled = false;
            sg_estado.Enabled = false;
            cd_cep.Enabled = false;
            cd_cnpj.Enabled = false;
            cd_ie.Enabled = false;
            btnAnterior.Enabled = true;
            btnProximo.Enabled = true;
            btnNovo.Enabled = true;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = false;
            btnCancelar.Enabled = false;
            btnPesquisar.Enabled = true;
            btnImprimir.Enabled = true;
            btnSair.Enabled = true;
        }

        public frmFornecedor()
        {
            InitializeComponent();
        }


        private void frmFornecedor_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'cadastroDataSet.tbfornecedor'. Você pode movê-la ou removê-la conforme necessário.
            this.tbfornecedorTableAdapter.Fill(this.cadastroDataSet.tbfornecedor);
            DesabilitaEdicao();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            tbfornecedorBindingSource.MovePrevious();
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            tbfornecedorBindingSource.MoveNext();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            tbfornecedorBindingSource.AddNew();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            HabilitaEdicao();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            tbfornecedorBindingSource.RemoveCurrent();
            tbfornecedorTableAdapter.Update(cadastroDataSet.tbfornecedor);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Validate();
            tbfornecedorBindingSource.EndEdit();
            tbfornecedorTableAdapter.Update(cadastroDataSet.tbfornecedor);
            DesabilitaEdicao();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            tbfornecedorBindingSource.CancelEdit();
            DesabilitaEdicao();
        }

        private void cd_cnpj_Leave(object sender, EventArgs e)
        {
            double dig1=0, dig2=0;

            dig1 += double.Parse(cd_cnpj.Text.Substring(14, 1)) * 2;
            dig1 += double.Parse(cd_cnpj.Text.Substring(13, 1)) * 3;
            dig1 += double.Parse(cd_cnpj.Text.Substring(12, 1)) * 4;
            dig1 += double.Parse(cd_cnpj.Text.Substring(11, 1)) * 5;
            dig1 += double.Parse(cd_cnpj.Text.Substring(9, 1)) * 6;
            dig1 += double.Parse(cd_cnpj.Text.Substring(8, 1)) * 7;
            dig1 += double.Parse(cd_cnpj.Text.Substring(7, 1)) * 8;
            dig1 += double.Parse(cd_cnpj.Text.Substring(5, 1)) * 9;
            dig1 += double.Parse(cd_cnpj.Text.Substring(4, 1)) * 2;
            dig1 += double.Parse(cd_cnpj.Text.Substring(3, 1)) * 3;
            dig1 += double.Parse(cd_cnpj.Text.Substring(1, 1)) * 4;
            dig1 += double.Parse(cd_cnpj.Text.Substring(0, 1)) * 5;

            dig1 = dig1 % 11;
            dig1 = dig1 - 11;

            dig2 += double.Parse(cd_cnpj.Text.Substring(16, 1)) * 2;
            dig2 += double.Parse(cd_cnpj.Text.Substring(14, 1)) * 3;
            dig2 += double.Parse(cd_cnpj.Text.Substring(13, 1)) * 4;
            dig2 += double.Parse(cd_cnpj.Text.Substring(12, 1)) * 5;
            dig2 += double.Parse(cd_cnpj.Text.Substring(11, 1)) * 6;
            dig2 += double.Parse(cd_cnpj.Text.Substring(9, 1)) * 7;
            dig2 += double.Parse(cd_cnpj.Text.Substring(8, 1)) * 8;
            dig2 += double.Parse(cd_cnpj.Text.Substring(7, 1)) * 9;
            dig2 += double.Parse(cd_cnpj.Text.Substring(5, 1)) * 2;
            dig2 += double.Parse(cd_cnpj.Text.Substring(4, 1)) * 3;
            dig2 += double.Parse(cd_cnpj.Text.Substring(3, 1)) * 4;
            dig2 += double.Parse(cd_cnpj.Text.Substring(1, 1)) * 5;
            dig2 += double.Parse(cd_cnpj.Text.Substring(0, 1)) * 6;

            dig2 = dig2 % 11;
            dig2 = dig2 - 11;

            if (cd_cnpj.Text.Substring(16,1) != dig1.ToString() || cd_cnpj.Text.Substring(17,1) != dig2.ToString())
            {
                MessageBox.Show("CNPJ Inválido!!!");
            }
        }
    }
}
