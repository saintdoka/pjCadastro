﻿namespace ProjetoCadastro
{


    partial class CadastroDataSet
    {
    }
}

namespace ProjetoCadastro.CadastroDataSetTableAdapters {
    
    
    public partial class tbusuarioTableAdapter {
    }
}
